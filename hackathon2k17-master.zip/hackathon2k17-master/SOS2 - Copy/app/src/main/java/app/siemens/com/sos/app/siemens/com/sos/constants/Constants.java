package app.siemens.com.sos.app.siemens.com.sos.constants;

/**
 * Created by d3sbma on 6/13/2017.
 */

public interface Constants {

    String TASK_URL = "http://132.186.66.81:8080/alarm/alarmData";
}
